package com.fm.modules.app.historial;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.ImageView;

import com.fm.modules.R;
import com.fm.modules.adapters.RecyclerHistorialDriverAdapter;
import com.fm.modules.adapters.RecyclerPedidosAdapter;
import com.fm.modules.app.login.Logued;
import com.fm.modules.app.pedidos.Principal;
import com.fm.modules.entities.RespuestaPedidosDriver;
import com.fm.modules.models.Driver;
import com.fm.modules.models.Pedido;
import com.fm.modules.service.PedidoService;

import java.util.ArrayList;
import java.util.List;

public class HistorialDriver extends AppCompatActivity {

    ImageView leftArrow;
    RecyclerView rvHistorialDriver;

    HistoDriver histoDriver = new HistoDriver();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_historial_driver);


        leftArrow = findViewById(R.id.left_arrow);
        rvHistorialDriver = findViewById(R.id.rvHistorialDriver);

        histoDriver.execute();
    }

    public void reiniciarAsynkProcess() {
        histoDriver.cancel(true);
        histoDriver = new HistoDriver();
    }

    public class HistoDriver extends AsyncTask<String, String, List<Pedido>> {

        @Override
        protected List<Pedido> doInBackground(String... strings) {
            List<Pedido> pedidos = new ArrayList<>();
            Driver driver = Logued.driverLogued;
            try {
                PedidoService pedidoService = new PedidoService();
                pedidos = pedidoService.historialPedidoDriver(String.valueOf(driver.getDriverId()));

            }catch (Exception e){
                System.out.println("Error en UnderThreash:" +e.getMessage() +" " +e.getClass());
            }
            return pedidos;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(List<Pedido> pedidos) {
            super.onPostExecute(pedidos);
            reiniciarAsynkProcess();
            try {
                if (!pedidos.isEmpty()){
                    RecyclerHistorialDriverAdapter adapter = new RecyclerHistorialDriverAdapter(getApplicationContext(), pedidos);
                    rvHistorialDriver.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                    rvHistorialDriver.setAdapter(adapter);
                    //Logued.respuestaPedidosDriverLogued = pedidos.get(0);

                    System.out.println("Aqui Obteniendo Respuesta Pedidos" +Logued.respuestaPedidosDriverLogued.toString());
                    //System.out.println("Aqui Obteniendo Respuesta Pedidos" +Logued.respuestaPedidosDriverLogued.toString());
                    //obtenerPedido.execute();

                }else{
                    RecyclerHistorialDriverAdapter adapter = new RecyclerHistorialDriverAdapter(getApplicationContext(), pedidos);
                    rvHistorialDriver.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                    rvHistorialDriver.setAdapter(adapter);
                }
            }catch (Throwable throwable){
                System.out.println("Error Activity: " +throwable.getMessage());
                throwable.printStackTrace();
            }
        }

        @Override
        protected void onProgressUpdate(String... values) {
            super.onProgressUpdate(values);
        }
    }
}