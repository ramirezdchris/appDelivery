package com.fm.modules.app.pedidos;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.text.Html;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import com.fm.modules.R;
import com.fm.modules.adapters.RecyclerPedidosAdapter;
import com.fm.modules.adapters.ViewPagerAdapter;
import com.fm.modules.app.historial.HistorialDriver;
import com.fm.modules.app.login.Logued;
import com.fm.modules.app.perfil.PerfilDriver;
import com.fm.modules.entities.RespuestaPedidosDriver;
import com.fm.modules.models.Driver;
import com.fm.modules.models.Pedido;
import com.fm.modules.service.DriverService;
import com.fm.modules.service.PedidoService;
import com.google.android.material.tabs.TabItem;
import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class Principal extends AppCompatActivity {

    public static long START_TIME_IN_MILLIS = 1800000;

    CountDownTimer mCountDownTimer;
    private boolean mTimerRunning;
    private long mTimeLeftMillis = START_TIME_IN_MILLIS;

    TextView tvTiempo;
    RecyclerView rvPedidoAEntregar;
    Button btnActivarStatus;
    Button btnVerHistorial;
    Switch switch1;


    PedidosDriver pedidosDriver = new PedidosDriver();
    ActualizarPedido actualizarPedido = new ActualizarPedido();
    ActualizarDriver actualizarDriver = new ActualizarDriver();
    ObtenerPedido obtenerPedido = new ObtenerPedido();
    ActualizarPedidoParaLlevar actualizarPedidoParaLlevar = new ActualizarPedidoParaLlevar();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.act_principal);


        tvTiempo = findViewById(R.id.tvTiempo);
        rvPedidoAEntregar = findViewById(R.id.rvPedidoAEntregar);
        btnActivarStatus = findViewById(R.id.btnActivarStatus);
        btnVerHistorial = findViewById(R.id.btnVerHistorial);
        switch1 = findViewById(R.id.switch1);
        tvTiempo.setText("Tiempo Restante");

        switch1.setVisibility(View.INVISIBLE);
        pedidosDriver.execute();

        switch1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b){
                    actualizarPedidoParaLlevar.execute();
                    startTimer();
                }
            }
        });

        btnActivarStatus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Activando Status", Toast.LENGTH_SHORT).show();
                actualizarPedido.execute();
            }
        });

        btnVerHistorial.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Mostrando Historial", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(getApplicationContext(), HistorialDriver.class);
                startActivity(i);
            }
        });
    }

    private void startTimer(){
        mCountDownTimer = new CountDownTimer(mTimeLeftMillis, 1000) {
            @Override
            public void onTick(long l) {
                mTimeLeftMillis = l;
                updateCountDownText();
            }

            @Override
            public void onFinish() {

            }
        }.start();
        mTimerRunning = true;
    }

    private void updateCountDownText(){
        int minutes = (int) (mTimeLeftMillis / 1000) / 60;
        int seconds = (int) (mTimeLeftMillis / 1000) % 60;

        String timeLeftFormatted = String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds);
        tvTiempo.setText("Tiempo restante: " +timeLeftFormatted);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.app_navigator_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.menuPerfil:
                //Toast.makeText(Principal.this, "menuShoppingCart", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(Principal.this, PerfilDriver.class);
                startActivity(i);
                break;

        }
        return true;
    }

    public void reiniciarAsynkProcess() {
        pedidosDriver.cancel(true);
        pedidosDriver = new PedidosDriver();

        obtenerPedido.cancel(true);
        obtenerPedido = new ObtenerPedido();

        actualizarPedido.cancel(true);
        actualizarPedido = new ActualizarPedido();

        actualizarDriver.cancel(true);
        actualizarDriver = new ActualizarDriver();

        actualizarPedidoParaLlevar.cancel(true);
        actualizarPedidoParaLlevar = new ActualizarPedidoParaLlevar();
    }

    public class PedidosDriver extends AsyncTask<String, String, List<RespuestaPedidosDriver>> {

        @Override
        protected List<RespuestaPedidosDriver> doInBackground(String... strings) {
            List<RespuestaPedidosDriver> pedidos = new ArrayList<>();
            Driver driver = Logued.driverLogued;
            try {
                PedidoService pedidoService = new PedidoService();
                pedidos = pedidoService.obtenerPedidoDriver(String.valueOf(driver.getDriverId()));

            }catch (Exception e){
                System.out.println("Error en UnderThreash:" +e.getMessage() +" " +e.getClass());
            }
            return pedidos;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(List<RespuestaPedidosDriver> pedidos) {
            super.onPostExecute(pedidos);
            reiniciarAsynkProcess();
            try {
                if (!pedidos.isEmpty()){
                    RecyclerPedidosAdapter adapter = new RecyclerPedidosAdapter(getApplicationContext(), pedidos);
                    rvPedidoAEntregar.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                    rvPedidoAEntregar.setAdapter(adapter);
                    Logued.respuestaPedidosDriverLogued = pedidos.get(0);
                    System.out.println("Aqui Obteniendo Respuesta Pedidos" +Logued.respuestaPedidosDriverLogued.toString());
                    //System.out.println("Aqui Obteniendo Respuesta Pedidos" +Logued.respuestaPedidosDriverLogued.toString());
                    obtenerPedido.execute();
                    switch1.setVisibility(View.VISIBLE);
                }else{
                    RecyclerPedidosAdapter adapter = new RecyclerPedidosAdapter(getApplicationContext(), pedidos);
                    rvPedidoAEntregar.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                    rvPedidoAEntregar.setAdapter(adapter);
                }
            }catch (Throwable throwable){
                System.out.println("Error Activity: " +throwable.getMessage());
                throwable.printStackTrace();
            }
        }

        @Override
        protected void onProgressUpdate(String... values) {
            super.onProgressUpdate(values);
        }
    }

    public class ObtenerPedido extends AsyncTask<String, String, Pedido> {

        @Override
        protected Pedido doInBackground(String... strings) {
            Pedido pedido = new Pedido();
            try {
                PedidoService pedidoService2 = new PedidoService();
                pedido = pedidoService2.obtenerPedidoPorId(Logued.respuestaPedidosDriverLogued.getPedidoId());
            }catch (Exception e){
                System.out.println("Error en UnderThreash ActualizarPedidoce:" +e.getMessage() +" " +e.getClass());
            }
            return pedido;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(Pedido pedido) {
            super.onPostExecute(pedido);
            try {
                Logued.pedidoLogued = pedido;
                System.out.println(Logued.pedidoLogued.toString());
            }catch (Throwable throwable){
                System.out.println("Error Activity: " +throwable.getMessage());
                throwable.printStackTrace();
            }
        }

        @Override
        protected void onProgressUpdate(String... values) {
            super.onProgressUpdate(values);
        }
    }

    public class ActualizarPedido extends AsyncTask<String, String, List<Pedido>> {

        @Override
        protected List<Pedido> doInBackground(String... strings) {
            List<Pedido> usuarios = new ArrayList<>();
            Driver driver = Logued.driverLogued;
            try {
                PedidoService pedidoService2 = new PedidoService();
                Logued.pedidoLogued.setStatus(4);
                Logued.pedidoLogued.setPedidoPagado(true);
                pedidoService2.actualizarPedidoPorId(Logued.pedidoLogued);

            }catch (Exception e){
                System.out.println("Error en UnderThreash ActualizarPedidoce:" +e.getMessage() +" " +e.getClass());
            }
            return usuarios;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(List<Pedido> pedidos) {
            super.onPostExecute(pedidos);
            try {
                actualizarDriver.execute();
                System.out.println("Actualizar Driver");
                Intent i = new Intent(Principal.this, Principal.class);
                i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(i);
            }catch (Throwable throwable){
                System.out.println("Error Activity: " +throwable.getMessage());
                throwable.printStackTrace();
            }
        }

        @Override
        protected void onProgressUpdate(String... values) {
            super.onProgressUpdate(values);
        }
    }

    public class ActualizarPedidoParaLlevar extends AsyncTask<String, String, List<Pedido>> {

        @Override
        protected List<Pedido> doInBackground(String... strings) {
            List<Pedido> usuarios = new ArrayList<>();
            Driver driver = Logued.driverLogued;
            try {
                PedidoService pedidoService2 = new PedidoService();
                Logued.pedidoLogued.setStatus(3);
                Logued.pedidoLogued.setPedidoPagado(false);
                pedidoService2.actualizarPedidoPorId(Logued.pedidoLogued);

            }catch (Exception e){
                System.out.println("Error en UnderThreash ActualizarPedidoce:" +e.getMessage() +" " +e.getClass());
            }
            return usuarios;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(List<Pedido> pedidos) {
            super.onPostExecute(pedidos);
            try {
                reiniciarAsynkProcess();
            }catch (Throwable throwable){
                System.out.println("Error Activity: " +throwable.getMessage());
                throwable.printStackTrace();
            }
        }

        @Override
        protected void onProgressUpdate(String... values) {
            super.onProgressUpdate(values);
        }
    }

    public class ActualizarDriver extends AsyncTask<String, String, Driver> {

        @Override
        protected Driver doInBackground(String... strings) {
            List<Pedido> usuarios = new ArrayList<>();
            Driver driver = Logued.driverLogued;
            try {
                PedidoService pedidoService2 = new PedidoService();
                DriverService driverService = new DriverService();
                Logued.driverLogued.setStatusAsignado(false);
                System.out.println("Driver a actualizar: " +Logued.driverLogued.toString());
                driverService.actualizarDriverPorId(Logued.driverLogued);
                driver = Logued.driverLogued;
                reiniciarAsynkProcess();
            }catch (Exception e){
                System.out.println("Error en Underhreash ActualizarPedidoce:" +e.getMessage() +" " +e.getClass());
            }
            return driver;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(Driver driver) {
            super.onPostExecute(driver);
            try {
                if (driver != null){

                    //Toast.makeText(context, "Usuario Cargados" +pedidos.size(), Toast.LENGTH_SHORT).show();
                }else{
                    //Toast.makeText(context, "Usuario No Cargados" +pedidos.size(), Toast.LENGTH_SHORT).show();
                    //reiniciarAsynkProcess();
                }
                reiniciarAsynkProcess();
            }catch (Throwable throwable){
                System.out.println("Error Activity: " +throwable.getMessage());
                throwable.printStackTrace();
            }
        }

        @Override
        protected void onProgressUpdate(String... values) {
            super.onProgressUpdate(values);
        }
    }
}
