package com.fm.modules.app.login;

import com.fm.modules.entities.RespuestaPedidosDriver;
import com.fm.modules.models.Driver;
import com.fm.modules.models.Pedido;

public class Logued {

    public static Driver driverLogued;
    public static RespuestaPedidosDriver respuestaPedidosDriverLogued;
    public static Pedido pedidoLogued;
}
